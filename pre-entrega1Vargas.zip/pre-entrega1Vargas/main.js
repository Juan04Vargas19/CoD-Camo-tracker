let intentos = 0
let oroAr 
let oroSmg 
let oroLmg 
let platino 
let poli 

//función para preguntar nombre de usuario o correo al user
function preguntarUsuario(){
    let usuario = prompt('Ingresa tu correo o nombre de usuario.')

    //Correo válido para el simulador: juanvargas@gmail.com || Usuario válido para el simulador: juanvargas98
    if(usuario === 'juanvargas@gmail.com' || usuario === 'juanvargas98'){
        preguntarContrasena()
    } else{
        alert('Correo o usuario inválidos, inténtalo nuevamente.')
        preguntarUsuario()
    }
}

//función para preguntar contraseña al user
function preguntarContrasena(){
    let password = prompt('Ingresa tu contraseña.')

    while(password !== '1234' && intentos <3){
        alert('Contraseña equivocada, intente nuevamente')
        intentos++
        password = prompt('Ingresa tu contraseña.')
    }
    
    if(intentos === 3){
        alert('Excediste el límite de intentos. \nPor favor vuelve más tarde.')
    } else if(password === '1234'){
        alert('Bienvenido Juan')
        preguntarOro()
    }
}

preguntarUsuario()

//función para preguntar la cantidad de camuflajes oro por categoría que ha desbloqueado el usuario
function preguntarOro(){
    oroAr = Number(prompt('¿Cuántos camuflajes oro de rifles de asalto has desbloqueado?'))
    oroSmg = Number(prompt('¿Cuántos camuflajes oro de subfusiles has desbloqueado?'))
    oroLmg = Number(prompt('¿Cuántos camuflajes oro de ametralladoras ligeras has desbloqueado?'))

    if(oroAr >= 8 || oroSmg >= 8 || oroLmg >= 5){
        preguntarPlatino()
    } else{
        alert('Necesitas completar los camuflajes requeridos por categoría para desbloquear los desafíos de Platino')
    }
}

//función para preguntar el total de camuflajes platino que ha desbloqueado el usuario
function preguntarPlatino(){
    platino = Number(prompt('¿Cuántos camuflajes de platino has desbloqueado en total?'))

    if(platino >= 21){
        preguntarPoli()
    } else{
        alert('Necesitas completar 21 camuflajes de platino en total para desbloquear los desafíos de Poliatómico')
    }
}

//función para preguntar el total de camuflajes poliatómicos que ha desbloqueado el usuario
function preguntarPoli(){
    poli = Number(prompt('¿Cuántos camuflajes de poliatómico has desbloqueado en total?'))
    let camoFaltantes = 21 - poli

    if(poli >= 21){
        alert('¡Felicidades! Has desbloqueado el camuflaje Orion.')
    } else{
        alert('Te falta(n) ' + camoFaltantes + ' camuflajes para desbloquear Orion')
    }
}